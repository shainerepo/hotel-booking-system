
package hotel;
import java.util.*;



class Booking{
    Queue<String> Res_ID;
    Queue<String> Room_number;
    Queue<String> Geust_Name;
    Queue<String> Phone_Number;
    Queue<String> Checking_date;
    Queue<String> Checkout_date;
    Queue<Double> num_pass;
    Queue<Double> discount_list;
    Queue<Double> total_list;
    Queue<Double> num_pass_child;
    Scanner scn;
    public Booking(){
        Res_ID = new LinkedList<>();
        Room_number = new LinkedList<>();
        Geust_Name = new LinkedList<>();
        Phone_Number = new LinkedList<>();
        Checking_date = new LinkedList<>();
        Checkout_date = new LinkedList<>();
        num_pass = new LinkedList<>();
        num_pass_child = new LinkedList<>();
        discount_list = new LinkedList<>();
        total_list = new LinkedList<>();
    }
    public void ShowData(){
        System.out.println("\t\t\t-------------------");
        System.out.println("\t\t\tAll Booking Details");
        System.out.println("\t\t\t-------------------");
        String[] ResIDArray = Res_ID.toArray(new String[Res_ID.size()]);
        String[] Room_numberArray = Room_number.toArray(new String[Room_number.size()]);
        String[] Geust_NameArray = Geust_Name.toArray(new String[Geust_Name.size()]);
        String[] Phone_NumberArray = Phone_Number.toArray(new String[Phone_Number.size()]);
        String[] Checking_dateArray = Checking_date.toArray(new String[Checking_date.size()]);
        String[] Checkout_dateArray = Checkout_date.toArray(new String[Checkout_date.size()]);
        Double[] Discount_dateArray = discount_list.toArray(new Double[discount_list.size()]);
        Double[] Total_dateArray = total_list.toArray(new Double[total_list.size()]);
        Double[] NP_dateArray = num_pass.toArray(new Double[num_pass.size()]);
        Double[] NCHild = num_pass_child.toArray(new Double[num_pass_child.size()]);

        for(int i = 0;i<ResIDArray.length;i++){
                System.out.println("-------------------");
                System.out.println("Res ID : "+ResIDArray[i]+"\nRoom Number : "+Room_numberArray[i]+"\nName : "+Geust_NameArray[i]+"\nPhone Number : "+Phone_NumberArray[i]+"\nCheckin Date : "+Checking_dateArray[i]+"\nCheckout Date : "+Checkout_dateArray[i]+"\nNum Of Adult."+NP_dateArray[i]+"\nNum Of Child : "+NCHild[i]+"\nDiscount : "+Discount_dateArray[i]+"\nTotal : "+Total_dateArray[i]);
                System.out.println("-------------------");
        }
        
        double total_amount = 0;
        double total_dis=0;
        for(int i = 0;i<Total_dateArray.length;i++){
            total_amount = total_amount + Total_dateArray[i];
        }
        for(int i = 0;i<Discount_dateArray.length;i++){
            total_dis = total_dis + Discount_dateArray[i];
        }
        System.out.println("\n-------------------");
        System.out.println("Total Booked : "+Res_ID.size());
        System.out.println("Total Discount : "+total_dis);
        System.out.println("Total Amount : "+total_amount);
    }
    
    public int AddData(){
        int data;
        System.out.println("Do You want a add data press 1 to view all details press 0");
        scn = new Scanner(System.in);
        int bc = scn.nextInt();
        if(bc == 0){
            data = 0;
        }else if(bc == 1){
            String Reseve_ID = this.GenerateResID();
            System.out.println("\nAdd New Booking Data");
            System.out.print("Enter Room Number : ");
            scn = new Scanner(System.in);
            String RNum = scn.nextLine();
            int room_ava = this.CheckRoom(RNum);
            if(room_ava == 1){
                System.out.println("This room is already booked !");
                data = 1;
            }else{
                System.out.print("Enter Your Name : ");
                scn = new Scanner(System.in);
                String g_name = scn.nextLine();
                System.out.print("Enter Your Phone Number : ");
                scn = new Scanner(System.in);
                String p_num = scn.nextLine();
                System.out.print("Checking Date : ");
                scn = new Scanner(System.in);
                String c_date = scn.nextLine();
                System.out.print("Checkout Date : ");
                scn = new Scanner(System.in);
                String ck_date = scn.nextLine();
                System.out.print("Adult : ");
                scn = new Scanner(System.in);
                double r_pas = scn.nextInt();
                System.out.print("Child : ");
                scn = new Scanner(System.in);
                double c_pas = scn.nextInt();
                double adult_price = 0;
                double child_price =0;
                adult_price = r_pas * 1000;
                child_price = c_pas * 500;
                double dis_amount = 0;
                double total = 0;
                if(r_pas >= 5){
                    dis_amount = 500;
                }else{
                    dis_amount = 0;
                }
                total = (adult_price + child_price)-dis_amount;
                discount_list.add(dis_amount);
                total_list.add(total);
                num_pass.add(r_pas);
                num_pass_child.add(c_pas);
                Checkout_date.add(ck_date);
                Checking_date.add(c_date);
                Phone_Number.add(p_num);
                Geust_Name.add(g_name);
                Room_number.add(RNum);
                Res_ID.add(Reseve_ID);
                System.out.println("\tRoom Booked \nRes ID is : "+Reseve_ID+"\nRoom Number : "+RNum+"\nName : "+g_name+"\nPhone Number : "+p_num+"\nChecking Date : "+c_date+"\nCheckout Date : "+ck_date+"\nNum of Adult : "+r_pas+"\nNum of Child : "+c_pas+"\nDiscount : "+dis_amount+"\nTotal : "+total);
                data = 1;
            }
           
        }else{
            data = 0;
        }
         return data;
    }
   
    public int CheckRoom(String RoomNum){
        int found = 0;
        for(String r_num : Room_number){
               if(r_num.equals(RoomNum)){
                   found = 1;
                   
                   break;
               }
        }
        return found;
    }
    public String GenerateResID(){
        int c_size = Res_ID.size();
        int n_size = c_size + 1;
        String ResID = "Res-"+Integer.toString(n_size);
        return ResID;
    }
}

public class Hotel {
    
    public static void main(String[] args) {
        System.out.println("\t\t\tWelcome to the hotel");
        Booking Book = new Booking();
            int st = 1;
            while(st != 0){
                st = Book.AddData();
            }
            Book.ShowData();
    }
    
}
